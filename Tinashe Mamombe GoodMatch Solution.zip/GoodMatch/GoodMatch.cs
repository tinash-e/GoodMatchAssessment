﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace GoodMatch
{
    /// <summary>
    ///   This class contains the logic needed to find a GoodMatch (i.e a match percentage between a female and male tennis player)
    /// </summary>
    public class GoodMatch
    {
        private Dictionary<char, int> Occurences; //{key, value} = {a char in the sentence, no. of occurences}
        private ArrayList OccurenceChecker; //required to avoid processing the same char in the sentence twice when building number sequence

        public GoodMatch()
        {
            Occurences = new Dictionary<char, int>();
            OccurenceChecker = new ArrayList();
        }

        /// <summary>
        ///This method (function) find the match percentage between male and female tennis player. 
        ///This function takes in a sentence(with male and female) name as a parameter
        /// </summary>
        /// <param name="sentence">A sentence made up of first name of the both male and female</param>
        /// <returns>A two digit number (in string format) representing %match</returns>
        public string getMatchPercentage(string sentence)
        {
            OccurenceChecker.Clear();
            Occurences.Clear();
            //store occurences in a dictionary (attempting to process the string in O(n) time complexity)
            for(int x = 0; x< sentence.Length ; x++)
            {
                char curChar = sentence[x];
                if (Occurences.ContainsKey(curChar))
                {
                    //int value = Occurences[curChar];
                    Occurences[curChar]++;
                    //value++; //increment the occurence of this character in the dictionary
                }
                else
                    Occurences.Add(curChar, 1);
            }

            //now build numberSequence
            string numberSequence = "";
            for(int x = 0; x<sentence.Length; x++)
            {
                char curChar = sentence[x];
                if (!OccurenceChecker.Contains((char)curChar))
                {
                    int charValue = Occurences[curChar]; //grab from Dictionary
                    numberSequence += charValue; //append to number sequence

                    OccurenceChecker.Add(curChar); //add to the checker ArrayList
                }
            }

            string result = getReducedValue(numberSequence); //get 2 digit value
            return result;
        }

        /// <summary>
        ///         This method is called by getMatchPercentage() and it reduces the numberSequence that is parsed 
        ///         by the calling method to a 2 digit number.This 2 digit number is returned as a string so that it is appended to the sentence in the end.
        /// </summary>
        /// <param name="numberSequence">A  number sequence generated from the sentence parsed by the calling method (getPercentage()) e.g 22221</param>
        /// <returns>A two digit num (string)</returns>
        private string getReducedValue(string numberSequence)
        {
            bool isReduced = false;
            string curSequence = numberSequence; //gain reference to the parsed sequence
            int forwardPointer = 0; //leftmost index
            int backwardPointer = 0; //rightmost index
            char forwardChar, backwardChar; //leftmost and rightmost chars
            int v1, v2; //leftmost and rightmost values

            while (!isReduced)
            {
                string nextSequence = ""; // a sequence that will be built

                //stopping condition per each sequence is determined by the curSequence length
                int seqLength = curSequence.Length; //get the length of the current sequence

                backwardPointer = curSequence.Length - 1; //where to start from the back
                if ((seqLength % 2) == 0) // current sequence is even
                {
                    while((backwardPointer - forwardPointer) > 0) //stop when pointer pass each other (stopping condition)
                    {
                        forwardChar = curSequence[forwardPointer];
                        v1 = int.Parse(forwardChar.ToString()); //convert to int

                        backwardChar = curSequence[backwardPointer];
                        v2 = int.Parse(backwardChar.ToString()); //convert to int
                        nextSequence += (v1 + v2);
                        
                        //move the pointers
                        forwardPointer++;
                        backwardPointer--;
                    }
                }
                else //current sequence is odd
                {
                    while(forwardPointer != backwardPointer) //both pointers will meet at some point (stopping condition)
                    {
                        forwardChar = curSequence[forwardPointer];
                        v1 = int.Parse(forwardChar.ToString()); //convert to int

                        backwardChar = curSequence[backwardPointer];
                        v2 = int.Parse(backwardChar.ToString()); //convert to int
                        nextSequence += (v1 + v2);

                        //move the pointers
                        forwardPointer++;
                        backwardPointer--;

                        if(forwardPointer == backwardPointer) //referencing the same element
                        {
                            char finalChar = curSequence[forwardPointer];
                            int finalV = int.Parse(finalChar.ToString()); //convert to int
                            nextSequence += finalV; //append to next sequence
                        }
                    }
                }
                forwardPointer = 0; //reset pointers
                backwardPointer = 0;

                curSequence = nextSequence; //let cur have next's value
                if (curSequence.Length == 2)// i.e has been reduced
                    isReduced = true;
            }

            return curSequence;
        }
    }
}
