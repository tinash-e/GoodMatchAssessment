﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;

namespace GoodMatch
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string matches = "matches";
            string maleName;
            string femaleName;
            GoodMatch goodMatch = new GoodMatch();

            Console.WriteLine("=============WELCOME TO THE GOOD MATCH PROGRAM==========");
            Console.WriteLine("Options:");
            Console.WriteLine("1. Enter two input strings");
            Console.WriteLine( "2. Read from CSV file. Note: file located in the bin folder");
            Console.WriteLine();
            Console.WriteLine("Enter option number:");
            int optionNum = int.Parse(Console.ReadLine());

            if (optionNum == 1)
            {
                do
                {
                    Console.WriteLine("Please enter a valid male's first name?"); //request input01 from user
                    maleName = Console.ReadLine();
                } while (!inputValid(maleName.ToUpper()));

                do
                {
                    Console.WriteLine("Please enter the female's first name?"); //request input02 from user
                    femaleName = Console.ReadLine();
                } while (!inputValid(femaleName.ToUpper()));

                string sentence = maleName.ToUpper() + matches.ToUpper() + femaleName.ToUpper(); //{name01}matches{name02}
                string percent = goodMatch.getMatchPercentage(sentence); //percentage value
                int percentValue = int.Parse(percent);

                if (percentValue >= 80)
                    percent += "%, good match";
                else
                    percent += "%";

                sentence = maleName + " " + matches + " " + femaleName + " " + percent; //sentence with spaces
                Console.WriteLine(sentence);
            }
            else if(optionNum ==2)
            {
                Dictionary<string, ArrayList> TennisPlayers = new Dictionary<string, ArrayList>(); //a list that will contain tennis players (grouped by gender)
                TennisPlayers.Add("f", new ArrayList());
                TennisPlayers.Add("m", new ArrayList());

                //fetch the data
                readFromCSVFile("players.csv", TennisPlayers);
                evaluateAllParticipants(matches, TennisPlayers, goodMatch);
            }
            else
            {
                Console.WriteLine("Invalid input");
            }
            Console.WriteLine("=========================END REGION====================");
            Console.ReadLine();
        }

        /*This method checks to see if the input provided by the user contains
         alphabetic characters ONLY. 
        Returns True if valid; False otherwise*/
        /// <summary>
        /// This method checks to see if the input provided by the user contains alphabetic
        /// characters only.
        /// </summary>
        /// <param name="name">The first name of the tennis player provided by the user</param>
        /// <returns>True if input is valid ; False if unexpected input found</returns>
        private static bool inputValid(string name)
        {
            char[] alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            for(int x = 0; x<name.Length; x++)
            {
                bool found = false;
                char curChar = name[x];
                for(int y = 0; y<alphabet.Length; y++)
                {
                    char alphaChar = alphabet[y];
                    if (curChar.Equals(alphaChar))
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Method reads competitors from a CSV file and populates Dictionary with tennisPlayers grouped based on gender
        /// </summary>
        /// <param name="fileName">players.csv</param>
        /// <param name="players"> A dictionary of players {key-value} -> {gender, list of competitors</param>
        private static void readFromCSVFile(string fileName, Dictionary<string, ArrayList> players)
        {
            Console.WriteLine("Reading from " + fileName + " located in the bin folder");
            StreamReader SR = new StreamReader(fileName);
            while (!SR.EndOfStream)
            {
                string[] data = SR.ReadLine().Split(',');
                string playerFirstName = data[0];
                string gender = data[1];

                ArrayList participants = players[gender];

                //handle unexpected input before storing name
                if (inputValid(playerFirstName.ToUpper()))
                {
                    if (!participants.Contains(playerFirstName))
                        participants.Add(playerFirstName);
                }else
                    Console.WriteLine($"The tennis player: " + playerFirstName + " could not be added due to invalid input from " + fileName);
            }
            SR.Close();
        }

        /// <summary>
        /// Evaluates matches for all the males against the females
        /// </summary>
        /// <param name="matches">A string called "matches"</param>
        /// <param name="players">A dictionary with key-value pair {gender, list of player names}</param>
        /// <param name="goodMatch">An instance containing logic for the good match algorithm</param>
        private static void evaluateAllParticipants(string matches, Dictionary<string, ArrayList> players, GoodMatch goodMatch)
        {
            ArrayList males = players["m"];
            ArrayList females = players["f"];

            ArrayList Percentages = new ArrayList(); // a list of matches' percentages
            Dictionary<string, int> resultMatches = new Dictionary<string, int>(); //{key, value} == {match, percentage}

            foreach(string maleFirstName in males)
            {
                foreach(string femaleFirstName in females)
                {
                    string sentence = maleFirstName.ToUpper() + matches.ToUpper() + femaleFirstName.ToUpper(); //{name01}matches{name02}
                    string percent = goodMatch.getMatchPercentage(sentence); //percentage value
                    int percentV = int.Parse(percent);

                    string s = maleFirstName + " " + matches + " " + femaleFirstName;

                    if(!Percentages.Contains(percentV)) //add without duplicates
                        Percentages.Add(percentV);

                    resultMatches.Add(s, percentV);
                }
            }

            Percentages.Sort();
            Percentages.Reverse();  //organise percentage in descending order
            ArrayList sortedMatches = getSortedMatches(Percentages, resultMatches);

            foreach(string match in sortedMatches)
                Console.WriteLine(match); //a quick display

            //save to textfile
            saveToFile("output.txt", sortedMatches);
            Console.WriteLine();
            Console.WriteLine("Matches saved to output.txt located in the bin folder");
        }

        /// <summary>
        ///         This method iterates through the sorted Percentages and selects the matches that correspond to them. 
        ///         If there are two or more matches with same %, then they are sorted based on alphabetical order
        /// </summary>
        /// <param name="Percentages"> A list containing generated percentages</param>
        /// <param name="resultMatches">A map/Dictionary of {key-value} == {match(excluding %), percentage}</param>
        /// <returns>A list containing matches sorted in descending based on %</returns>
        private static ArrayList getSortedMatches(ArrayList Percentages, Dictionary<string, int> resultMatches)
        {
            ArrayList sortedMatches = new ArrayList(); // a list that will contain the sorted matches
            ArrayList samePercentMatch = new ArrayList(); // a list of matches with the same percentage value

            foreach(int percentV in Percentages)
            {
                //find matches that correspond to the percent
                foreach(KeyValuePair<string ,int> match in resultMatches)
                {
                    if (match.Value == percentV)
                        samePercentMatch.Add(match.Key);
                }

                samePercentMatch.Sort(); //order matches alphabetically

                string percent = percentV.ToString();
                if (percentV >= 80)
                    percent += "%, good match";
                else
                    percent += "%";

                //Add sorted match to sortedMatches
                foreach (string match in samePercentMatch)
                    sortedMatches.Add(match + " " + percent);

                samePercentMatch.Clear();
            }

            return sortedMatches;
        }

        /*This method saves the goodmatch of all participants to a textfile*/
        /// <summary>
        /// This method saves the sorted matches of all the participants to a textfile
        /// </summary>
        /// <param name="fileName">output.txt</param>
        /// <param name="sortedMatches">A sorted list of all the matches</param>
        private static void saveToFile(string fileName, ArrayList sortedMatches)
        {
            try
            {
                StreamWriter writer = new StreamWriter(fileName); //open stream
                foreach (string match in sortedMatches)
                    writer.WriteLine(match);
                writer.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine("Could not save results to file");
                Console.WriteLine(e.StackTrace);
            }
        }
    }
}
